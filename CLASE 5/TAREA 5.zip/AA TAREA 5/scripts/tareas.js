let tareas = JSON.parse(localStorage.getItem("Tareas"));
if (tareas == null) tareas = [];
function addTarea(fecha, materia, descripcion, realizada) {
  let newTarea = {
    id : nextId(),
    fecha : fecha,
    materia : materia,
    descripcion : descripcion,
    realizada : realizada 
  }
  tarea.push(newTarea);
  localStorage.setItem("Tarea", JSON.stringify(tarea))
}
function deleteTarea(id) {
  let index = -1;
  for (let i = 0; i < tareas.length; i++) {
    if (tareas[i].id == id) index = i;
  }
  if (index != -1) tareas.splice(index, 1);
  localStorage.setItem("Tarea", JSON.stringify(tarea))
}
function modifyTarea(id, fecha, materia, descripcion, realizada) {
  for (tarea of tareas) {
    if (tarea.id == id) {
      tarea.fecha = fecha;
      tarea.materia = materia;
      tarea.descripcion = descripcion;
      tarea.realizada = realizada;
      break;
    }
  }
  localStorage.setItem("Tarea", JSON.stringify(tarea))
}
function getTarea(id) {
  // PARA HACER
  // Busque en el array llamado tareas. Dar como resultado la tarea que tiene como
  // id el argumento de la función.
  //
}
function nextId() {
  return 1
  // PARA HACER
  // Busque en el array de tareas el id máximo
  // De como resultado el máximo + 1
  // En caso de que no haya ninguna tarea todavía debe dar como resultado 1
  //
}
